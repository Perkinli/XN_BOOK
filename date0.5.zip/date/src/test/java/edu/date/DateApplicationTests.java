package edu.date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DateApplicationTests {

    @Test
    void contextLoads() {
    }


        @Autowired
        private RedissonClient redissonClient;

        @Test
        void testRedisConnection() {
            RBucket<String> bucket = redissonClient.getBucket("testKey");
            bucket.set("Hello Redis");
            Assertions.assertEquals("Hello Redis", bucket.get());
        }

}
