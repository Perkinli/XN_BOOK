package edu.date.config;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author xuzheng
 * @project com.hmdp.config
 * @data 2023/9/30
 */

@Configuration
public class RedissonConfig {

//    @Bean
//    public RedissonClient redissonClient(){
//
//        Config config = new Config();
//        config.useSingleServer().setAddress("redis://192.168.88.130:6379").setPassword("123456");
//        return Redisson.create(config);
//    }

}
