package edu.date.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import edu.date.VO.ActivityDetailVO;
import edu.date.VO.ActivityVO;
import edu.date.VO.CommentVO;
import edu.date.VO.FilterActivitiesVo;
import edu.date.context.BaseContext;
import edu.date.entity.*;
import edu.date.mapper.*;
import edu.date.service.ActivityService;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ActivityServiceImpl implements ActivityService {

    @Autowired
    private ActivityMapper activityMapper;
    @Autowired
    private UserMapper userMapper;

    public FilterActivitiesVo filterActivities(Map<String, Object> params) {

        // 构建查询条件
        QueryWrapper<Activity> wrapper = buildQueryWrapper(params);

        // 先查询符合条件的总数
        int total = activityMapper.selectCount(wrapper);

        // 再查询活动列表
        List<Activity> activities = activityMapper.selectList(wrapper);

        List<ActivityVO> activityVOS = activities.stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
        FilterActivitiesVo filterActivitiesVo = new FilterActivitiesVo();
        filterActivitiesVo.setActivityVO(activityVOS);
        filterActivitiesVo.setTotal(total);
        return filterActivitiesVo;
    }

    @Override
    public FilterActivitiesVo searchActivities(String keyword) {//FritteractivitiesVO 由list<activityVO>和total构成
        // 正确调用mapper方法
        QueryWrapper<Activity> wrapper = new QueryWrapper<>();
        wrapper.like("activity_name", keyword);
        int total = activityMapper.selectCount(wrapper);
        List<Activity> activities = activityMapper.selectList(wrapper);

        List<ActivityVO> activityVOS = activities.stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
        FilterActivitiesVo filterActivitiesVo = new FilterActivitiesVo();
        filterActivitiesVo.setActivityVO(activityVOS);
        filterActivitiesVo.setTotal(total);
        return filterActivitiesVo;
    }

    @Override
    public List<ActivityVO> recommendedActivities() {
        List<Activity> activities = activityMapper.selectTopHotActivities(6);
        return activities.stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
    }

    @Override
    public List<ActivityVO> getRelatedActivities(Integer activityId) {
        // 先尝试获取相关活动
        List<Activity> activities = activityMapper.selectRelatedActivities(activityId);

        // 如果不够3个，补充热门活动
        if (activities.size() < 3) {
            int remaining = 3 - activities.size();
            List<Activity> hotActivities = activityMapper.selectTopHotActivities(remaining);
            // 去重
            hotActivities.removeIf(hot ->
                    activities.stream().anyMatch(a -> a.getActivityId().equals(hot.getActivityId())));
            activities.addAll(hotActivities);
        }

        return activities.stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
    }

    @Autowired
    FocusMapper focusMapper;
    @Override
    public ActivityDetailVO getActivityDetail(Integer activityId) {
        Activity activity = activityMapper.selectById(activityId);
        log.info("getActivityDetail:{}", activityId);
        String userId = BaseContext.getCurrentId();
        int focus = focusMapper.selectCount(
                new QueryWrapper<Focus>()
                        .eq("activity_id", activityId)
                        .eq("user_id", userId)
        );
        ActivityDetailVO activityDetailVO = new ActivityDetailVO().builder()
                .activityName(activity.getActivityName())
                .description(activity.getDescription())
                .activityType(activity.getActivityType())
                .startTime(activity.getStartTime())
                .timeSpan(activity.getTimeSpan())
                .location(activity.getLocation())
                .organizer(activity.getOrganizer())
                .image(activity.getImage())
                .hot(activity.getHot())
                .hasLimit(activity.getMaxParticipants() > 0)
                .currentParticipants(activity.getCurrentParticipants())
                .maxParticipants(activity.getMaxParticipants())
                .requirements(activity.getRequirements())
                .relationPeople(activity.getRelationPeople())
                .relationEmail(activity.getRelationEmail())
                .isFocus(focus)
                .reserveStartTime(activity.getReserveStartTime())
                .build();
        return activityDetailVO;
    }

    @Autowired
    CommentMapper commentMapper;
    @Autowired
    CommentLikeMapper commentLikeMapper;
    @Override
    public List<CommentVO> getActivityComments(Integer activityId) {
        // 1. 查询基础评论列表
        QueryWrapper<Comment> commentWrapper = new QueryWrapper<>();
        commentWrapper.eq("activity_id", activityId)
                .orderByDesc("time");
        List<Comment> comments = commentMapper.selectList(commentWrapper);

        // 2. 批量收集用户ID和评论ID
        Set<String> userIds = comments.stream()
                .map(comment -> comment.getUserId().toString())
                .collect(Collectors.toSet());

        Set<Integer> commentIds = comments.stream()
                .map(Comment::getCommentId)
                .collect(Collectors.toSet());
        // 3. 批量查询用户信息
        Map<String, User> userMap = userMapper.selectBatchIds(userIds)
                .stream()
                .collect(Collectors.toMap(User::getUserId, Function.identity()));

        // 4. 批量查询当前用户的点赞记录
        String currentUserId = BaseContext.getCurrentId();
        List<CommentLike> userLikes = commentLikeMapper.selectList(
                new QueryWrapper<CommentLike>()
                        .eq("user_id", currentUserId)
                        .in("comment_id", commentIds)
        );
        Set<Integer> likedCommentIds = userLikes.stream()
                .map(CommentLike::getCommentId)
                .collect(Collectors.toSet());

        // 5. 组合数据为VO
        return comments.stream()
                .map(comment -> {
                    User user = userMap.get(comment.getUserId().toString());
                    return CommentVO.builder()
                            .commentId(comment.getCommentId())
                            .content(comment.getContent())
                            .userId(comment.getUserId().toString())
                            .userName(user != null ? user.getUserName() : "未知用户")
                            .department(user != null ? user.getDepartment() : "")
                            .time(comment.getTime())
                            .likes(comment.getLikes())
                            .avatar(user != null ? user.getAvatar() : "default-avatar.jpg")
                            .isLike(likedCommentIds.contains(comment.getCommentId())) // 检查是否点赞
                            .build();
                })
                .collect(Collectors.toList());
    }

    @Override
    public void updateActivityComments(Integer activityId, String content) {
        Comment comment = Comment.builder()
                .content(content)
                .userId(Integer.parseInt(BaseContext.getCurrentId()))
                .activityId(activityId)
                .time(LocalDateTime.now())
                .build();
        commentMapper.insert(comment);
    }

    private QueryWrapper<Activity> buildQueryWrapper(Map<String, Object> params) {
        QueryWrapper<Activity> wrapper = new QueryWrapper<>();
        //Limit
        String userId = BaseContext.getCurrentId();
        User user = userMapper.selectOne(
                new QueryWrapper<User>()
                        .select("grade", "department") // 指定查询字段
                        .eq("user_id", userId)
        );

        String limitOfCollage = user.getDepartment();
        wrapper.and(w -> w.eq("limit_of_collage", limitOfCollage).or().isNull("limit_of_collage"));

        String limitOfGrade = user.getGrade();
        wrapper.and(w -> w.eq("limit_of_grade", limitOfGrade).or().isNull("limit_of_grade"));

        // 组织者筛选（注意：表中organizer是字符串，不是ID）
        if (params.containsKey("organizer")) {
            wrapper.eq("organizer", params.get("organizer").toString());
        }

        if (params.containsKey("category")) {
            wrapper.eq("activity_type", params.get("category").toString());
        }

        // 热门活动筛选（hot是int类型，不是boolean）
        if (params.containsKey("hot") && Boolean.TRUE.equals(params.get("hot"))) {
            wrapper.gt("hot", 0); // 热度大于0的算热门
            // 或者 wrapper.orderByDesc("hot"); // 按热度降序
        }

        return wrapper;
    }

    private ActivityVO convertToVO(Activity activity) {
        return ActivityVO.builder()
                .activityId(activity.getActivityId())
                .activityName(activity.getActivityName())
                .activityType(activity.getActivityType())
                .startTime(activity.getStartTime())
                .timeSpan(activity.getTimeSpan())
                .location(activity.getLocation())
                .organizer(activity.getOrganizer())
                .image(activity.getImage())
                .hot(activity.getLikes() > 100 ? 1 : 0)  // 假设“热门”由点赞数决定
                .hasLimit(activity.getHasLimit())
                .currentParticipants(activity.getCurrentParticipants())
                .maxParticipants(activity.getMaxParticipants())
                .reserveStartTime(activity.getReserveStartTime())
                .build();
    }

}
