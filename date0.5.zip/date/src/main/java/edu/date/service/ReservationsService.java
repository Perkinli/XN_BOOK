package edu.date.service;

import edu.date.VO.HistoryReservationsVO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ReservationsService {
    int makeReservations(Integer activityId);

    void deleteReservations(Integer activityId);

    List<HistoryReservationsVO> getReservationsHistory();

    List<HistoryReservationsVO> getViolations();
}
