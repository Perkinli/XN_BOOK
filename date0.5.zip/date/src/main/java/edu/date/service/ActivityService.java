package edu.date.service;

import edu.date.VO.ActivityDetailVO;
import edu.date.VO.ActivityVO;
import edu.date.VO.CommentVO;
import edu.date.VO.FilterActivitiesVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public interface ActivityService {
    FilterActivitiesVo filterActivities(Map<String, Object> queryParams);

    FilterActivitiesVo searchActivities(String keyword);

    List<ActivityVO> recommendedActivities();

    List<ActivityVO> getRelatedActivities(Integer activityId);

    ActivityDetailVO getActivityDetail(Integer activityId);

    List<CommentVO> getActivityComments(Integer activityId);

    void updateActivityComments(Integer activityId, String content);
}
