package edu.date.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import edu.date.VO.HistoryReservationsVO;
import edu.date.context.BaseContext;
import edu.date.entity.Activity;
import edu.date.entity.UserActivity;
import edu.date.mapper.ActivityMapper;
import edu.date.mapper.UserActivityMapper;
import edu.date.mapper.ViolationReminderMapper;
import edu.date.service.ReservationsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReservationsServiceImpl implements ReservationsService {
    @Autowired
    private UserActivityMapper userActivityMapper;

    @Override
    public int makeReservations(Integer activityId) {

        // 检查是否已预约
        if (existsByUserAndActivity(BaseContext.getCurrentId(), activityId) ){
            return -1;
        }

        // 检查活动名额
        Activity activity = activityMapper.selectById(activityId);
        if (activity.getCurrentParticipants() >= activity.getMaxParticipants()) {
            return 0;
        }

        // 创建预约记录
        UserActivity userActivity = UserActivity.builder()
                .activityId(activityId)
                .userId(Integer.parseInt(BaseContext.getCurrentId()))
                .build();
        userActivityMapper.insert(userActivity);

        // 更新活动参与人数
        activityMapper.incrementParticipants(activityId);
        return 1;
    }

    @Override
    public void deleteReservations(Integer activityId) {
        // 1. 使用 QueryWrapper 构建条件
        QueryWrapper<UserActivity> wrapper = new QueryWrapper<>();
        wrapper.eq("activity_id", activityId);

        // 2. 执行删除
        userActivityMapper.delete(wrapper);
        return;
    }

    @Autowired
    private ActivityMapper activityMapper;
    @Override
    public List<HistoryReservationsVO> getReservationsHistory() {
        // 1. 获取当前用户ID
        Integer userId = Integer.parseInt(BaseContext.getCurrentId());

        // 2. 查询用户关联的activity_id列表
        QueryWrapper<UserActivity> userActivityWrapper = new QueryWrapper<>();
        userActivityWrapper.select("activity_id")
                .eq("user_id", userId);

        List<Integer> activityIds = userActivityMapper.selectList(userActivityWrapper)
                .stream()
                .map(UserActivity::getActivityId)
                .collect(Collectors.toList());

        if (activityIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 3. 批量查询活动详情（避免Lambda）
        QueryWrapper<Activity> activityWrapper = new QueryWrapper<>();
        activityWrapper.select(
                        "activity_id",
                        "activity_name",
                        "activity_type",
                        "start_time",
                        "time_span",
                        "location"
                )
                .in("activity_id", activityIds);

        return activityMapper.selectList(activityWrapper)
                .stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
    }

    @Autowired
    private ViolationReminderMapper violationReminderMapper;
    @Override
    public List<HistoryReservationsVO> getViolations() {
        Integer  userId = Integer.parseInt(BaseContext.getCurrentId());
        return activityMapper.selectHistoryReservations(userId);
    }

    public boolean existsByUserAndActivity(String userId, Integer activityId) {
        QueryWrapper<UserActivity> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
                .eq("activity_id", activityId);

        return userActivityMapper.selectCount(wrapper) > 0;
    }

    private HistoryReservationsVO convertToVO(Activity activity) {
        HistoryReservationsVO vo = new HistoryReservationsVO();
        vo.setActivityId(activity.getActivityId());
        vo.setActivityName(activity.getActivityName());
        vo.setActivityType(activity.getActivityType());
        vo.setStartTime(activity.getStartTime());
        vo.setTimeSpan(activity.getTimeSpan());
        vo.setLocation(activity.getLocation());
        return vo;
    }

}
