// 1. 用户实体类 (User)
package edu.date.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("tb_user") // 指定数据库表名
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    @TableId() // 指定主键，并设置为自增
    private String userId; // 主键字段

    private String userName;
    private String password;
    private Integer userType;
    private String grade;
    private String className;
    private String phone;
    private String department;
    private String email;
    private String gender;
    private LocalDateTime releaseTime;
    private Integer violateCount = 0;
    private Integer activityCount = 0;
    private String avatar;
}