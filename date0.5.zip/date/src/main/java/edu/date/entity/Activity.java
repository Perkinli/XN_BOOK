// 2. 活动实体类 (Activity)
package edu.date.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("tb_activity")
public class Activity implements Serializable {
    private static final long serialVersionUID = 1L;

    @TableId(value = "activity_id", type = IdType.AUTO)
    private Integer activityId;
    private String activityName;
    private Integer maxParticipants;
    private Integer currentParticipants = 0;
    private Integer likes = 0;
    private String activityType;
    private LocalDateTime reserveStartTime;
    private LocalDateTime reserveEndTime;
    private String limitOfGrade;
    private String limitOfCollage;
    private String location;
    private Boolean hasLimit;
    private String description;
    private String requirements;
    private String relationPeople;
    private String relationEmail;
    private String image;
    private LocalDateTime startTime;
    private String timeSpan;
    private String organizer;
    private int hot;
}