// 5. 消息实体类 (Message)
package edu.date.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Message implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer messageId;
    private String messageTitle;
    private String messageContent;
    private LocalDateTime currentTime;
    private String limitOfGrade;
    private String limitOfCollage;
}