// 7. 活动修改提醒实体类 (ActivityModification)
package edu.date.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActivityModification implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private Activity activity;
    private String content;
    private LocalDateTime currentTime;
}