// 8. 评论实体类 (Comment)
package edu.date.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("tb_comments")
public class Comment implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer commentId;
    private String content;
    private Integer userId;
    private Integer activityId;
    private LocalDateTime time;
    private Integer likes = 0;
}