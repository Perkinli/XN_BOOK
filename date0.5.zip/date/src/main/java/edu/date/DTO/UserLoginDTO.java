package edu.date.DTO;

import lombok.Data;

@Data
public class UserLoginDTO {
    private String userId;
    private String password;
    private Integer userType;
}
