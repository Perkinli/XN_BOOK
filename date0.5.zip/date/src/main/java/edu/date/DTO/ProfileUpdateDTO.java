package edu.date.DTO;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ProfileUpdateDTO {
    private String email;
    private String phone;
}
