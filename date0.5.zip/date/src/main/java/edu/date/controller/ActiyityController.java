package edu.date.controller;

import edu.date.VO.CommentVO;
import edu.date.DTO.Result;
import edu.date.VO.ActivityVO;
import edu.date.VO.FilterActivitiesVo;
import edu.date.service.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/activities")
public class ActiyityController {

    @Autowired
    private ActivityService activityService;

    @GetMapping("/filter")
    public Result filterActivities(
            @RequestParam(required = false) Integer organizer,
            @RequestParam(required = false) Integer category,
            @RequestParam(required = false) Boolean hot){
        // 构建查询条件
        Map<String, Object> queryParams = new HashMap<>();
        if (organizer != null) {
            queryParams.put("organizer", organizer);
        }
        if (category != null) {
            queryParams.put("category", category);
        }
        if (hot != null) {
            queryParams.put("hot", hot);
        }

        // 调用服务层查询
        FilterActivitiesVo activities = activityService.filterActivities(queryParams);

        // 按开始时间降序排序
        activities.getActivityVO().sort(Comparator.comparing(ActivityVO::getStartTime).reversed());

        return Result.success(activities);
    }

    @GetMapping("/search")
    public Result<FilterActivitiesVo> searchActivities(@RequestParam String keyword) {
        return Result.success(activityService.searchActivities(keyword));
    }

    @GetMapping("/recommended")
    public Result<List<ActivityVO>> recommendedActivities() {
        return Result.success(activityService.recommendedActivities());
    }

    @GetMapping("/{activityId}/related")
    public Result<List<ActivityVO>> relatedActivities(@PathVariable Integer activityId) {
        return Result.success(activityService.getRelatedActivities(activityId));
    }

    @GetMapping("/{activityId}")
    public Result getActivityDetail(@PathVariable Integer activityId){
        return Result.success(activityService.getActivityDetail(activityId));
    }

    @GetMapping("/{activityId}/comments")
    public Result<List<CommentVO>> getActivityComments(@PathVariable Integer activityId){
        return Result.success(activityService.getActivityComments(activityId));
    }

    @PutMapping("/{activityId}/comments")
    public Result updateActivityComments(@PathVariable Integer activityId, @RequestBody String content){
        activityService.updateActivityComments(activityId, content);
        return Result.success();
    }
}
