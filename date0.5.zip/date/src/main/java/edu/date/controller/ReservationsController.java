package edu.date.controller;

import edu.date.DTO.Result;
import edu.date.VO.HistoryReservationsVO;
import edu.date.service.ReservationsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationsController {
    @Autowired
    private ReservationsService reservationsService;
    @PostMapping("/{activityId}")
    public Result MakeReservations(@PathVariable Integer activityId) {

            int result = reservationsService.makeReservations(activityId);;

            if (result == 1) {
                return Result.success("预约成功");
            } else if (result == 0) {
                return Result.error("预约名额已满");
            } else {
                return Result.error("您已预约过该活动");
            }

    }

    @DeleteMapping("/{activityId}")
    public Result DeleteReservations(@PathVariable Integer activityId) {
        reservationsService.deleteReservations(activityId);
        return Result.success();
    }

    @GetMapping("/history")
    public Result<List<HistoryReservationsVO>> GetReservationsHistory() {
        return Result.success(reservationsService.getReservationsHistory());
    }

    @GetMapping("/violations")
    public Result<List<HistoryReservationsVO>> GetViolations() {
        return Result.success(reservationsService.getViolations());
    }
}
