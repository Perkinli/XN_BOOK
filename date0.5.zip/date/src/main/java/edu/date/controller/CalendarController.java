package edu.date.controller;

import edu.date.DTO.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/calendar")
public class CalendarController {


//    @GetMapping()
//    public Result<List<Integer>> getCalendar(@PathVariable String month) {
//        return ;
//    }
}
