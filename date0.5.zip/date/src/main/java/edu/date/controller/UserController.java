package edu.date.controller;

import edu.date.DTO.PasswordUpdateDTO;
import edu.date.DTO.ProfileUpdateDTO;
import edu.date.DTO.Result;
import edu.date.DTO.UserLoginDTO;
import edu.date.VO.UserLoginVO;
import edu.date.context.BaseContext;
import edu.date.entity.User;
import edu.date.properties.JwtProperties;
import edu.date.service.UserService;
import edu.date.utils.AliOSSUtils;
import edu.date.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @GetMapping("/profile")
    public Result<User> getProfile() {
        String userId = BaseContext.getCurrentId(); // 直接从线程变量获取
        if (userId == null) return Result.error("未登录");
        return Result.success(userService.getUserProfile(userId));
    }

    @PostMapping("/profile")
    public Result updateProfile(
                                @RequestParam(required = false) String email,
                                @RequestParam(required = false) String phone,
                                @RequestParam(required = false) MultipartFile avatar) throws IOException {
        String url = uploadImage(avatar);
        if(userService.updateProfile(email,phone))
            return Result.success(url);
        return Result.error("更改个人信息失败");
    }

    @PutMapping("/password")
    public Result updatePassword(@RequestBody PasswordUpdateDTO passwordUpdateDTO) {
        String oldPassword = passwordUpdateDTO.getOldPassword();
        String newPassword = passwordUpdateDTO.getNewPassword();
        if(userService.updatePassword(oldPassword, newPassword))
            return Result.success();

        return Result.error("updatePassword失败");

    }


    @Autowired
    private AliOSSUtils aliOSSUtils;
    public String uploadImage(MultipartFile image) throws IOException {
        return aliOSSUtils.upload(image);
    }
}