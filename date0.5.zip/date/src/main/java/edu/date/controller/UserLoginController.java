package edu.date.controller;

import edu.date.DTO.Result;
import edu.date.DTO.UserLoginDTO;
import edu.date.VO.UserLoginVO;
import edu.date.context.BaseContext;
import edu.date.entity.User;
import edu.date.properties.JwtProperties;
import edu.date.service.UserService;
import edu.date.utils.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class UserLoginController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;
    @Autowired
    private JwtProperties jwtProperties;

    @PostMapping("/login")
    public Result<UserLoginVO> login(@RequestBody UserLoginDTO userLoginDTO) {

        log.info("用户登录：{}", userLoginDTO);

        User user = userService.login(userLoginDTO);

        //登录成功后，生成jwt令牌
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", user.getUserId());
        String token = JwtUtil.createJWT(
                jwtProperties.getUserSecretKey(),
                jwtProperties.getUserTtl(),
                claims);

        //将登录者的id放到当前线程中
        BaseContext.setCurrentId(user.getUserId());

        log.info("UserLoginController-BaseContext.getCurrentId():{}", BaseContext.getCurrentId());
        UserLoginVO userLoginVO = UserLoginVO.builder()
                .id(user.getUserId())
                .userName(user.getUserName())
                .token(token)
                .build();

        return Result.success(userLoginVO);
    }

}
