package edu.date.VO;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class FilterActivitiesVo {
    private List<ActivityVO> activityVO;
    private int total;
}
