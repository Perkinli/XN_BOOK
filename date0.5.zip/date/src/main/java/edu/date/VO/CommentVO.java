package edu.date.VO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommentVO {
    private Integer commentId;
    private String content;
    private String userId;
    private String userName;
    private String department;
    private LocalDateTime time;
    private Integer likes;
    private Boolean isLike;
    private String avatar;
}