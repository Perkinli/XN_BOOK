package edu.date.VO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActivityVO {
    private Integer activityId;          // 活动ID
    private String activityName;        // 活动标题
    private String activityType;       // 活动类别
    private LocalDateTime startTime;          // 活动开始时间
    private String timeSpan;           // 活动持续时间
    private String location;          // 活动地点
    private String organizer;         // 活动组织者
    private String image;            // 活动图片URL
    private Integer hot;             // 是否热门 (1是/0否)
    private Boolean hasLimit;        // 是否有预约限制 (1是/0否)
    private Integer currentParticipants; // 当前预约人数
    private Integer maxParticipants;    // 最大预约人数
    private LocalDateTime reserveStartTime;    // 预约开始时间
}