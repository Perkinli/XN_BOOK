package edu.date.VO;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class HistoryReservationsVO {
    private Integer activityId;          // 活动ID
    private String activityName;        // 活动标题
    private String activityType;       // 活动类别
    private LocalDateTime startTime;          // 活动开始时间
    private String timeSpan;           // 活动持续时间
    private String location;          // 活动地点
}
