package edu.date.VO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ActivityDetailVO {
    private Integer activityId;
    private String activityName;
    private String activityType;
    private LocalDateTime startTime;
    private String timeSpan;
    private String location;
    private String organizer;
    private String image;
    private int hot;
    private Boolean hasLimit;
    private Integer currentParticipants;
    private Integer maxParticipants;
    private String description;
    private String requirements;
    private String relationPeople;
    private String relationEmail;
    private int isFocus;
    private LocalDateTime reserveStartTime;


}
