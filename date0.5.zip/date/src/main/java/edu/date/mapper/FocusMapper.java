package edu.date.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import edu.date.entity.Focus;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FocusMapper extends BaseMapper<Focus> {

}
