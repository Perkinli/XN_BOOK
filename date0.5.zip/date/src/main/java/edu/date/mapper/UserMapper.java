package edu.date.mapper;

import edu.date.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    // 使用MyBatis-Plus提供的基础CRUD方法

    @Select("select * from tb_user where user_name = #{userName}")
    User getByUserName(String userName);

    @Update("UPDATE tb_user SET password = #{newPassword} WHERE user_id = #{userId} AND password = #{oldPassword}")
    int updatePassword(
            @Param("userId") String userId,
            @Param("oldPassword") String oldPassword,
            @Param("newPassword") String newPassword
    );

    @Update("UPDATE tb_user SET phone = #{phone}, email = #{email} WHERE user_id = #{userId}")
    int updateProfile(
            @Param("userId") String userId,
            @Param("phone") String phone,
            @Param("email") String email
    );

}
