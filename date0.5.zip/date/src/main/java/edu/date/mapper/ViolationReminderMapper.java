package edu.date.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ViolationReminderMapper extends BaseMapper<edu.date.entity.ViolationReminder> {
}
