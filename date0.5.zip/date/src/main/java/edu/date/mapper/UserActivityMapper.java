package edu.date.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import edu.date.context.BaseContext;
import edu.date.entity.UserActivity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserActivityMapper extends BaseMapper<UserActivity> {
}
