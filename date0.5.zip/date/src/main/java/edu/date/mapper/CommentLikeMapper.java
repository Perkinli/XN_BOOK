package edu.date.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import edu.date.entity.Comment;
import edu.date.entity.CommentLike;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CommentLikeMapper extends BaseMapper<CommentLike> {
}
