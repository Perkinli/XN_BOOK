package edu.date.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import edu.date.VO.HistoryReservationsVO;
import edu.date.entity.Activity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ActivityMapper extends BaseMapper<Activity> {

    @Select("SELECT * FROM tb_activity ORDER BY likes DESC LIMIT #{limit}")
    List<Activity> selectTopHotActivities(@Param("limit") int limit);

    @Select("SELECT * FROM tb_activity " +
            "WHERE activity_id != #{activityId} " +
            "AND (activity_type = (SELECT activity_type FROM tb_activity WHERE activity_id = #{activityId}) " +
            "     OR organizer = (SELECT organizer FROM tb_activity WHERE activity_id = #{activityId})) " +
            "ORDER BY likes DESC " +
            "LIMIT 3")
    List<Activity> selectRelatedActivities(@Param("activityId") Integer activityId);

    @Update("UPDATE tb_activity SET current_participants = current_participants + 1 WHERE activity_id = #{activityId}")
    int incrementParticipants(@Param("activityId") Integer activityId);


    @Select("SELECT " +
            "a.activity_id, a.activity_name, a.activity_type, " +
            "a.start_time, a.time_span, a.location " +
            "FROM tb_activity a " +
            "JOIN tb_violation_reminder ua ON a.activity_id = ua.activity_id " +
            "WHERE ua.user_id = #{userId}")
    List<HistoryReservationsVO> selectHistoryReservations(@Param("userId") Integer userId);

}
