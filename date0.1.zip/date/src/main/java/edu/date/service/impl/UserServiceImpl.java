package edu.date.service.impl;

import edu.date.DTO.UserLoginDTO;
import edu.date.context.BaseContext;
import edu.date.entity.User;
import edu.date.mapper.UserMapper;
import edu.date.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

@Service // 添加@Service注解，确保该类被Spring容器管理
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    public User login(UserLoginDTO userLoginDTO) {
        String userId = userLoginDTO.getUserId();
        String password = userLoginDTO.getPassword();

        //1、根据用户名查询数据库中的数据
        User user = userMapper.selectById(userId);

        //2、处理各种异常情况（用户名不存在、密码不对、账号被锁定）
        if (user == null) {
            //账号不存在
            throw new RuntimeException("账号不存在");
        }

        //密码比对
        //对前端传过来的明文密码进行md5加密处理
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        if (!password.equals(user.getPassword())) {
            //密码错误
            throw new RuntimeException("密码错误 ");
        }

        //3、返回实体对象
        return user;
    }

    public User getUserProfile(String userId) {
        return userMapper.selectById(userId);
    }

    @Override
    public Boolean updatePassword(String oldPassword, String newPassword) {
        String userId = BaseContext.getCurrentId(); // 直接从线程变量获取
        //1、根据用户id查询用户
        User user = userMapper.selectById(userId);

        oldPassword = DigestUtils.md5DigestAsHex(oldPassword.getBytes());

        if(oldPassword != user.getPassword())
            return false;

        newPassword = DigestUtils.md5DigestAsHex(newPassword.getBytes());

        user.setPassword(newPassword);

        return true;
    }
}