package edu.date.service;

import edu.date.DTO.UserLoginDTO;
import edu.date.entity.User;
import edu.date.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public interface UserService {


    User login(UserLoginDTO employeeLoginDTO);

    User getUserProfile(String userId);

    Boolean updatePassword(String oldPassword, String newPassword);
}