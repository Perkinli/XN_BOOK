package edu.date.mapper;

import edu.date.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    // 使用MyBatis-Plus提供的基础CRUD方法

    @Select("select * from tb_user where user_name = #{userName}")
    User getByUserName(String userName);

}
