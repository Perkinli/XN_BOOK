// 3. 管理员-活动关联实体类 (AdminActivity)
package edu.date.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdminActivity implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private User user;
    private Activity activity;
}