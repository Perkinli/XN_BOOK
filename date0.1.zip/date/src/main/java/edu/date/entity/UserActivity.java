// 4. 用户-活动参与实体类 (UserActivity)
package edu.date.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserActivity implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer reservationId;
    private Activity activity;
    private User user;
    private Integer checkinYes = 0;
    private Integer checkoutYes = 0;
}