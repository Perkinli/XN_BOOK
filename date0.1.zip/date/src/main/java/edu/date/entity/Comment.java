// 8. 评论实体类 (Comment)
package edu.date.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Comment implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer commentId;
    private String content;
    private User user;
    private Activity activity;
    private LocalDateTime time;
    private Integer likes = 0;
}