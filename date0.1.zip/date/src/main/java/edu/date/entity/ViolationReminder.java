// 6. 违规提醒实体类 (ViolationReminder)
package edu.date.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ViolationReminder implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private User user;
    private Activity activity;
    private LocalDateTime currentTime;
}