package edu.date.config;

import edu.date.DTO.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestControllerAdvice
public class WebExceptionAdvice {
    private static final Logger log = LoggerFactory.getLogger(WebExceptionAdvice.class);
    @ExceptionHandler(RuntimeException.class)
    public Result handleRuntimeException(RuntimeException e) {
        log.error(e.toString(), e);
        return Result.error("服务器异常");
    }
}
