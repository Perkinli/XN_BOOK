package edu.date.controller;


import edu.date.DTO.Result;
import edu.date.utils.AliOSSUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Slf4j
@RestController
@RequestMapping("/api/auth")
public class ImageController {

    @Autowired
    private AliOSSUtils aliOSSUtils;

    @PostMapping("/image")
    public Result upload(MultipartFile image) throws IOException {
        return Result.success(aliOSSUtils.upload(image));
    }
}
